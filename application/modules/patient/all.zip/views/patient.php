<style>
#hidden_div1 {
    display: none;
}
#hidden_div2 {
    display: none;
}
#hidden_div3 {
    display: none;
}
#hidden_div10 {
    display: none;
}
#hidden_div11 {
    display: none;
}
</style>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">
        <!-- page start-->
        <section class="">

            <header class="panel-heading">
                <?php echo lang('patient'); ?> <?php echo lang('database'); ?>
                <div class="col-md-4 no-print pull-right"> 
                    <a data-toggle="modal" href="#myModal">
                        <div class="btn-group pull-right">
                            <button id="" class="btn green btn-xs">
                                <i class="fa fa-plus-circle"></i> <?php echo "Add New Patient";//lang('add_new'); ?>
                            </button>
                        </div>
                    </a>
                </div>
            </header>
            <div class="panel-body">
				 <div class="col-lg-12">
                                        <div class="col-lg-3"></div>
                                        <div class="col-lg-6">
                                            <?php echo validation_errors(); ?>
                                        </div>
                                        <div class="col-lg-3"></div>
                                    </div>
                <div class="adv-table editable-table ">

                    <div class="space15"></div>
                    <table class="table table-striped table-hover table-bordered" id="editable-sample">
                        <thead>
                            <tr>
                                <th><?php echo lang('patient_id'); ?></th>                        
                               <th><?php echo 'Alias';//lang('name'); ?></th>
                                <th><?php echo 'Firstname';//lang('name'); ?></th>
                                <th><?php echo 'Lastname';//lang('name'); ?></th>
                                <th><?php echo lang('phone'); ?></th>
                                <th><?php echo "D.O.B";//lang('phone'); ?></th> 
                                <?php if ($this->ion_auth->in_group(array('admin', 'Accountant', 'Receptionist','Nurse'))) { ?>
                                    <th><?php echo lang('due_balance'); ?></th>
                                <?php } ?>
                                <th class="no-print"><?php echo lang('options'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <style>
                            .img_url{
                                height:20px;
                                width:20px;
                                background-size: contain; 
                                max-height:20px;
                                border-radius: 100px;
                            }
                        </style>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        <!-- page end-->
    </section>
</section>
<!--main content end-->
<!--footer start-->






<!-- Add Patient Modal-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg" style="width: 80%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">  <?php echo lang('register_new_patient'); ?></h4>
            </div>
            <div class="modal-body row">
                <form role="form" action="patient/addNew" class="clearfix" method="post" enctype="multipart/form-data" autocomplete="off">
				<div class="form-group col-md-12">
				<b><h2 style="float:left;"><u>Personal Information</u></h2></b>
				</div>
                    <div class="form-group col-md-6">
                        <label for="Fullname"><?php echo 'Alias'; //lang('name'); ?></label>
                        <input type="text" class="form-control" name="name" >
                    </div>                    
					<div class="form-group col-md-6">
                        <label for="Firstname"><?php echo 'First Name'; //lang('name'); ?></label>
                        <input type="text" class="form-control" name="first_name"  required>
                    </div>                    
					<div class="form-group col-md-6">
                        <label for="Lastname"><?php echo 'Last Name'; //lang('name'); ?></label>
                        <input type="text" class="form-control" name="last_name"  required>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="email"><?php echo lang('email'); ?></label>
                        <input type="text" class="form-control" name="email"  value='<?php echo rand()."@ispecs.com"; ?>'  placeholder="" >
                    </div>

                    <div class="form-group col-md-6">
                        <label for="password"><?php echo lang('password'); ?></label>
                        <input type="password" class="form-control" name="password" id="exampleInputPassword1" value="<?php echo rand(); ?>"  placeholder="">
                    </div>



                    <div class="form-group col-md-6">
                        <label for="Address" ><?php echo 'Complete Address'; //lang('address'); ?></label>
                    <textarea class="form-control"  name="address" rows="3" ></textarea>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="phone"><?php echo lang('phone'); ?></label>
                        <input type="text" class="form-control" name="phone"  value='' placeholder="" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="exampleInputSex"><?php echo 'Gender';//lang('sex'); ?></label>
                        <select class="form-control m-bot15" name="sex" value=''>

                            <option value="Male" <?php
                            if (!empty($patient->sex)) {
                                if ($patient->sex == 'Male') {
                                    echo 'selected';
                                }
                            }
                            ?> > Male </option>
                            <option value="Female" <?php
                            if (!empty($patient->sex)) {
                                if ($patient->sex == 'Female') {
                                    echo 'selected';
                                }
                            }
                            ?> > Female </option>
                            <option value="Others" <?php
                            if (!empty($patient->sex)) {
                                if ($patient->sex == 'Others') {
                                    echo 'selected';
                                }
                            }
                            ?> > Others </option>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label><?php echo lang('birth_date'); ?></label>
                        <input class="form-control form-control-inline input-medium default-date-picker" type="text" name="birthdate" value="" placeholder="" readonly="">      
                    </div>

                    <div class="form-group col-md-6">    
                        <label for="exampleInputEmail1"><?php echo lang('doctor'); ?></label>
                        <select class="form-control js-example-basic-single"  name="doctor" value=''> 
                            <option value=""> </option>
                            <?php foreach ($doctors as $doctor) { ?>                                        
                                <option value="<?php echo $doctor->id; ?>"><?php echo $doctor->name; ?> </option>
                            <?php } ?> 
                        </select>
                    </div>
					
					<div class="form-group col-md-6">
                     <label for="examination">  Is this your first examination at this office? &nbsp;&nbsp; </label>
					   	<select name="first_time" class="form-control form-control-inline input-medium" onchange="showDiv1('hidden_div1', this)">
						<option value="">&darr;&darr; Please select one &darr;&darr;</option>
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>     
                    </div>	
					
				
					<script type="text/javascript">
					function showDiv1(divId, element)
						{
							document.getElementById(divId).style.display = element.value == "YES" ? 'block' : 'none';
							//document.getElementById(divId).style.display = element.value == "NO" ? 'none' : 'block';
						}

            function ref(str){
                document.getElementById('oth').style.display = 'none';
                document.getElementById('ins').style.display = 'none';
                document.getElementById('ref').style.display = 'block';
                document.getElementById('dir2').style.display = 'none';
            }            
			function ins(str){
                document.getElementById('oth').style.display = 'none';
                document.getElementById('ins').style.display = 'block';
                document.getElementById('ref').style.display = 'none';
                document.getElementById('dir2').style.display = 'none';
            }			
			function oth(str){
                document.getElementById('oth').style.display = 'block';
                document.getElementById('ins').style.display = 'none';
                document.getElementById('ref').style.display = 'none';
                document.getElementById('dir2').style.display = 'none';
            }			
			function dir2(str){
                document.getElementById('oth').style.display = 'none';
                document.getElementById('ins').style.display = 'none';
                document.getElementById('ref').style.display = 'none';
                document.getElementById('dir2').style.display = 'block';
            }

						
					</script>

					<div class="form-group col-md-6" id="hidden_div1">
					<label for="howdid">  How did you hear about us? </label> <br>
						<input type="radio" name="hear_about" id="ref2" onchange="ref()" /> Referred by: <br>
						<div id="ref" style="display:none;">
						<input class="form-control form-control-inline input-medium " type="text" name="ref_by" />
						</div>
						<input type="radio" name="hear_about" id="ins2" onchange="ins()" /> Insurance Company: <br>
						<div id="ins" style="display:none;">
						<input class="form-control form-control-inline input-medium " type="text" name="ins_company" /></div>					
						<input type="radio" name="hear_about" id="dir3"   onchange="dir2()" /> Directory: <br>
						<div id="dir2" style="display:none;">
						<input class="form-control form-control-inline input-medium " type="text" name="hear_about_dir"  /></div>
						<input type="radio" name="hear_about" id="oth1" onchange="oth()" /> Others: <br>
						<div id="oth" style="display:none;">
						<input class="form-control form-control-inline input-medium " type="text" name="hear_others" /></div>
						
					</div>					
					
					
					
					

<hr width="100%" />

<!-- medical history -->
					<div class="form-group col-md-12">
				<b><h2 style="float:left;"><u>Medical History</u></h2></b>
				</div>
				<input type="hidden" class="default" name="img_url" value="./uploads/patient.jpg" />

					<div class="form-group col-md-6">
                        <label for="examination">Reasons for today's examination</label>
                        <input type="text" class="form-control" name="reason_examination" id="reason_examination" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_relations">Date of last Physical Examination</label>
                        <input class="form-control form-control-inline input-medium default-date-picker" name="physical_examination" id="physical_examination" value='' placeholder="">
                    </div>	

<div class="form-group col-md-12">
<label for="agree">Have you had any of the following? (Please tick Yes or No)</label>
  <div class="row">
    <div class="form-group col-md-4">
		<p><b>YES &nbsp;&nbsp; NO </b></p><p>
		<input type="radio" name="glaucoma"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="glaucoma"  value="NO"  /> &nbsp;
		<label for="glaucoma">Glaucoma</label><br>		
		<input type="radio" name="cataracts"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="cataracts"  value="NO"  /> &nbsp;
		<label for="cataracts">Cataracts</label><br>		
		<input type="radio" name="eye_surgery"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="eye_surgery"  value="NO"  /> &nbsp;
		<label for="eye_surgery">Eye Surgery</label><br>		
		<input type="radio" name="lazy_eye"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="lazy_eye"  value="NO"  /> &nbsp;
		<label for="lazy_eye">Lazy Eye/Eye /turn</label><br>		
		
		<input type="radio" name="light_flashes"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="light_flashes"  value="NO"  /> &nbsp;
		<label for="light_flashes">Light Flashes</label><br>		
		<input type="radio" name="eye_injury"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="eye_injury"  value="NO"  /> &nbsp;
		<label for="eye_injury">Eye Injury</label>

    </div>
	<div class="form-group col-md-4">
		<p><b>YES &nbsp;&nbsp; NO </b></p><p>
		<input type="radio" name="floaters"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="floaters"  value="NO"  /> &nbsp;
		<label for="floaters">Sudden increase in Floaters</label><br>						
		<input type="radio" name="sick_others1"  value="YES"  onchange="showDiv10('hidden_div10', this)" /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="sick_others1"  value="NO"  onchange="showDiv10('hidden_div10', this)" /> &nbsp;
					<script type="text/javascript">
						function showDiv10(divId, element)
							{
								document.getElementById(divId).style.display = element.value == "YES" ? 'block' : 'none';
								document.getElementById(divId).style.display = element.value == "NO" ? 'none' : 'block';
							}					
					</script>		
		<label for="sick_others">Others</label>	
		<div id="hidden_div10">
			<label for="othersickness_yes">Please list other sickness </label>
			<input class="form-control form-control-inline input-medium " type="text" name="sick_others" />
		</div>			
		<input type="radio" name="thyroid_disease"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="thyroid_disease"  value="NO"  /> &nbsp;		
		<label for="thyroid_disease">Thyroid Disease</label><br>		
		<input type="radio" name="sinusitis"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="sinusitis"  value="NO"  /> &nbsp;
		<label for="sinusitis">Sinusitis</label><br>		
		
		<input type="radio" name="hiv"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="hiv"  value="NO"  /> &nbsp;
		<label for="hiv">HIV</label><br>		
    </div>	
	
    <div class="form-group col-md-4">
		<p><b>YES &nbsp;&nbsp; NO </b></p><p>
		<input type="radio" name="blood_pressure2"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="blood_pressure2"  value="NO"  /> &nbsp;
		<label for="blood_pressure2">Blood Pressure</label><br>		
		<input type="radio" name="diabetes"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="diabetes"  value="NO"  /> &nbsp;
		<label for="diabetes">Diabetes</label><br>		
		<input type="radio" name="asthma"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="asthma"  value="NO"  /> &nbsp;
		<label for="asthma">Asthma</label><br>		
		<input type="radio" name="respiratory_problem"  value="YES"  /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="respiratory_problem"  value="NO"  /> &nbsp;
		<label for="respiratory_problem">Other lungs or respiratory problems</label><br>		
		
		
		<input type="radio" name="problem_others1"  value="YES"  onchange="showDiv11('hidden_div11', this)" /> &nbsp;&nbsp; &nbsp;&nbsp;
		<input type="radio" name="problem_others1"  value="NO"  onchange="showDiv11('hidden_div11', this)" /> &nbsp;
					<script type="text/javascript">
						function showDiv11(divId, element)
							{
								document.getElementById(divId).style.display = element.value == "YES" ? 'block' : 'none';
								document.getElementById(divId).style.display = element.value == "NO" ? 'none' : 'block';
							}					
					</script>		
		<label for="problem_others">Other (describe)</label>
		<div id="hidden_div11">
			<label for="othersickness_yes">Please Describe sickness </label>
			<input class="form-control form-control-inline input-medium " type="text" name="problem_others" />
		</div>		
				
    </div>    

  </div>
</div>
			
<style>
#hidden_div4 {
    display: none;
}
#hidden_div5 {
    display: none;
}
#hidden_div6 {
    display: none;
}
</style>

					<div class="form-group col-md-6">
                     <label for="medications">  Are you currently taking medications? &nbsp;&nbsp; </label>
					   	<select name="taking_medications" class="form-control form-control-inline input-medium" onchange="showDiv4('hidden_div4', this)">
						<option value="">&darr;&darr; Please select one &darr;&darr;</option>
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>     
                    </div>	
					
				
					<script type="text/javascript">
					function showDiv4(divId, element)
						{
							document.getElementById(divId).style.display = element.value == "YES" ? 'block' : 'none';
							//document.getElementById(divId).style.display = element.value == "NO" ? 'none' : 'block';
						}					
					function showDiv5(divId, element)
						{
							document.getElementById(divId).style.display = element.value == "YES" ? 'block' : 'none';
							//document.getElementById(divId).style.display = element.value == "NO" ? 'none' : 'block';
						}						
						
					function showDiv6(divId, element)
						{
							document.getElementById(divId).style.display = element.value == "YES" ? 'block' : 'none';
							//document.getElementById(divId).style.display = element.value == "NO" ? 'none' : 'block';
						}
	
					</script>

					<div class="form-group col-md-6" id="hidden_div4">
					<label for="medications_yes">Please list medications </label> <br>
						<input class="form-control form-control-inline input-medium " type="text" name="medications_yes" />
					</div>					
					
					<div class="form-group col-md-6">
                     <label for="medications">Are you interested in wearing contact lenses? &nbsp;&nbsp; </label>
					   	<select name="wearing_contact_lens" class="form-control form-control-inline input-medium" onchange="showDiv5('hidden_div5', this)">
						<option value="">&darr;&darr; Please select one &darr;&darr;</option>
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>     
                    </div>	

					<div class="form-group col-md-6" id="hidden_div5">
					<label for="allergies_list">Please list allergies </label> <br>
						<input class="form-control form-control-inline input-medium " type="text" name="allergies_list" />
					</div>	
					
					
					<div class="form-group col-md-6">
                     <label for="allergies">Other  &nbsp;&nbsp; </label>
						<input class="form-control form-control-inline input-medium " type="text" name="other_allergies" />
    
                    </div>						
					
					<div class="form-group col-md-6">
                       <label for="glasses"> Do you wear glasses? &nbsp;&nbsp; </label>
					   	<select name="wear_glasses" class="form-control form-control-inline input-medium">
						<option value="">&darr;&darr; Please select one &darr;&darr;</option>
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>     
                    </div>						
										
					<div class="form-group col-md-6">
                     <label for="worn_contacts">  Have you worn Contacts Lens? &nbsp;&nbsp; </label>
					   	<select name="worn_contacts" class="form-control form-control-inline input-medium" onchange="showDiv6('hidden_div6', this)">
						<option value="">&darr;&darr; Please select one &darr;&darr;</option>
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>     
                    </div>	
					
					<div class="form-group col-md-6" id="hidden_div6">
					<label for="contact_lens_yes">What type of contact lens </label> <br>
						<input class="form-control form-control-inline input-medium " type="text" name="contact_lens_yes" /> <br>
					<label for="contact_lens_hours">And how many hours per day? </label> <br>
						<input class="form-control form-control-inline input-medium " type="text" name="contact_lens_hours" />
					</div>	
					

					 <hr width="100%" />
					 
<!-- end of medical history -- >					 
				
					 <div class="form-group col-md-12">
					<center><h3>Next of Kin Information</h3></center>	
					</div>					

					<div class="form-group col-md-6">
                        <label for="kin_name"><?php echo lang('kin_name'); ?></label>
                        <input type="text" class="form-control" name="kin_name" id="kin_name" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_relations"><?php echo lang('kin_relations'); ?></label>
                        <input type="text" class="form-control" name="kin_relations" id="kin_relations" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_phone"><?php echo lang('kin_phone'); ?></label>
                        <input type="text" class="form-control" name="kin_phone" id="kin_phone" placeholder="">
                    </div>
					
					<div class="form-group col-md-6">
                        <label for="kin_email"><?php echo lang('kin_email'); ?></label>
                        <input type="text" class="form-control" name="kin_email" id="kin_email" placeholder="">
                    </div>
				-->	
                    <div class="form-group col-md-6">
                        <input type="checkbox" name="sms" value="sms"> <?php echo lang('send_sms') ?><br>
                    </div>
					
					 <hr width="100%" />
					 <div class="form-group col-md-6">
					<label for=""><h4> <u>AUTHORIZATION TO RELEASE INFORMATION</u> </h4></label> <p>					 
					<p>
					<label for="authorization"> Do you authorize "I" SPECS APPEAL to release any information necessary to process your insurance claims  </label>
					<select name="authorization" class="form-control form-control-inline input-medium" >
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>
					</div>	
    
                  
					<div class="form-group col-md-6">					 
					<label for=""><h4> <u>ASSIGNMENT OF INSURANCE BENEFITS:</u> </h3></label> <p>					 
					 <p>
                     <label for="assignment">Do you hereby authorize payments of medication benefits to "I SPECS APPEAL" for services rendered. <br>
					Do you understand that you are financially responsibly to "I SPECS APPEAL" for charges not covered by this assignment
					 </label>
					<select name="assignment" class="form-control form-control-inline input-medium" >
						<option value="NO">NO</option>
						<option value="YES">YES</option>
						</select>
					</div>
                   				
					
					
					
					


                    <section class="col-md-12">
                        <button type="submit" name="submit" class="btn btn-info pull-right"><?php echo lang('submit'); ?></button>
                    </section>
                </form>

            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!-- Add Patient Modal-->







<!-- Edit Patient Modal-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">  <?php echo lang('edit_patient'); ?></h4>
            </div>
            <div class="modal-body row">
                <form role="form" id="editPatientForm" autocomplete="off" action="patient/addNew" class="clearfix" method="post" enctype="multipart/form-data">

                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo 'Alias';//lang('name'); ?></label>
                        <input type="text" class="form-control" name="name" id="exampleInputEmail1" value='' placeholder="">
                    </div>                    
					<div class="form-group col-md-6">
                        <label for="Firstname"><?php echo 'First Name';//lang('name'); ?></label>
                        <input type="text" class="form-control" name="first_name" id="firstname" value='' placeholder="">
                    </div>                    
					<div class="form-group col-md-6">
                        <label for="lastname"><?php echo 'Last Name';//lang('name'); ?></label>
                        <input type="text" class="form-control" name="last_name" id="lastname" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo lang('email'); ?></label>
                        <input type="text" class="form-control" name="email" id="exampleInputEmail1" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo lang('change'); ?><?php echo lang('password'); ?></label>
                        <input type="password" class="form-control" name="password" id="exampleInputEmail1" placeholder="">
                    </div>



                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo lang('address'); ?></label>
                        <input type="text" class="form-control" name="address" id="exampleInputEmail1" value='' placeholder="">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo lang('phone'); ?></label>
                        <input type="text" class="form-control" name="phone" id="exampleInputEmail1" value='' placeholder="">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo lang('sex'); ?></label>
                        <select class="form-control m-bot15" name="sex" value=''>

                            <option value="Male" <?php
                            if (!empty($patient->sex)) {
                                if ($patient->sex == 'Male') {
                                    echo 'selected';
                                }
                            }
                            ?> > Male </option>
                            <option value="Female" <?php
                            if (!empty($patient->sex)) {
                                if ($patient->sex == 'Female') {
                                    echo 'selected';
                                }
                            }
                            ?> > Female </option>
                            <option value="Others" <?php
                            if (!empty($patient->sex)) {
                                if ($patient->sex == 'Others') {
                                    echo 'selected';
                                }
                            }
                            ?> > Others </option>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label><?php echo lang('birth_date'); ?></label>
                        <input class="form-control form-control-inline input-medium default-date-picker" type="text" name="birthdate" value="" placeholder="" readonly="">      
                    </div>

<!--
                    <div class="form-group col-md-6">
                        <label for="exampleInputEmail1"><?php echo lang('blood_group'); ?></label>
                        <select class="form-control m-bot15" name="bloodgroup" value=''>
                            <?php foreach ($groups as $group) { ?>
                                <option value="<?php echo $group->group; ?>" <?php
                                if (!empty($patient->bloodgroup)) {
                                    if ($group->group == $patient->bloodgroup) {
                                        echo 'selected';
                                    }
                                }
                                ?> > <?php echo $group->group; ?> </option>
                                    <?php } ?> 
                        </select>
                    </div>
-->
                    <div class="form-group col-md-6">    
                        <label for="exampleInputEmail1"><?php echo lang('doctor'); ?></label>
                        <select class="form-control js-example-basic-single doctor"  name="doctor" value=''> 
                            <option value=""> </option>
                            <?php foreach ($doctors as $doctor) { ?>                                        
                                <option value="<?php echo $doctor->id; ?>"><?php echo $doctor->name; ?> </option>
                            <?php } ?> 
                        </select>
                    </div>



                    <div class="form-group last col-md-6">
                        <label class="control-label">Image Upload</label>
                        <div class="">
                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                    <img src="www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" id="img" alt="" />
                                </div>
                                <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                <div>
                                    <span class="btn btn-white btn-file">
                                        <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select image</span>
                                        <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                        <input type="file" class="default" name="img_url"/>
                                    </span>
                                    <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload"><i class="fa fa-trash"></i> Remove</a>
                                </div>
                            </div>

                        </div>
                    </div>


                  <!--  
                    
                    <div class="form-group last col-md-6">
                        <div style="text-align:center;">
                            <video id="video" width="200" height="200" autoplay></video>
                            <div class="snap" id="snap">Capture Photo</div>
                            <canvas id="canvas" width="200" height="200"></canvas>
                            Right click on the captured image and save. Then select the saved image from the left side's Select Image button.
                        </div>
                    </div>
                    
                    -->


					 <hr width="100%" />
<!--					<div class="form-group col-md-12">
					<center><h3>Next of Kin Information</h3></center>	
					</div>				
					 <div class="form-group col-md-6">
                        <label for="kin_name"><?php echo lang('kin_name'); ?></label>
                        <input type="text" class="form-control" name="kin_name" id="kin_name" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_relations"><?php echo lang('kin_relations'); ?></label>
                        <input type="text" class="form-control" name="kin_relations" id="kin_relations" value='' placeholder="">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_phone"><?php echo lang('kin_phone'); ?></label>
                        <input type="text" class="form-control" name="kin_phone" id="kin_phone" placeholder="">
                    </div>
					
					<div class="form-group col-md-6">
                        <label for="kin_email"><?php echo lang('kin_email'); ?></label>
                        <input type="text" class="form-control" name="kin_email" id="kin_email" placeholder="">
                    </div>





                    <div class="form-group col-md-6">
                        <input type="checkbox" name="sms" value="sms"> <?php echo lang('send_sms') ?><br>
                    </div>
-->
                    <input type="hidden" name="id" value='<?php
                                        if (!empty($patient->id)) {
                                            echo $patient->id;
                                        }
                                        ?>'>
                    <input type="hidden" name="p_id" value='<?php
                    if (!empty($patient->patient_id)) {
                        echo $patient->patient_id;
                    }
                    ?>' >

				<section class="col-md-12">
                        <button type="submit" name="submit" class="btn btn-info pull-right"><?php echo lang('submit'); ?></button>
                    </section>

                </form>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
</div>
<!-- Edit Patient Modal-->


<div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg"> 
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">  <?php echo lang('patient'); ?>  <?php echo lang('info'); ?></h4>
            </div>
            <div class="modal-body row">
                <form role="form" autocomplete="off" id="editPatientForm" action="patient/addNew" class="clearfix" method="post" enctype="multipart/form-data">

                   <div class="form-group last col-md-4">
                        <div class="">
                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                    <img src="./uploads/patient.jpg" />
                                </div>
                             <!--   <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>-->
                            </div>
                            <div class="col-md-12">
                                <label for="exampleInputEmail1"><?php echo lang('patient_id'); ?>: <span class="patientIdClass"></span></label>
                            </div>
                        </div>

                    </div> 
                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1"><?php echo 'Alias';//lang('name'); ?></label>
                        <div class="nameClass"></div>
                    </div>                    
					<div class="form-group col-md-4">
                        <label for="firstname"><?php echo 'First Name';//lang('name'); ?></label>
                        <div class="firstnameClass"></div>
                    </div>                    
					<div class="form-group col-md-4">
                        <label for="lastname"><?php echo 'Last Name';//lang('name'); ?></label>
                        <div class="lastnameClass"></div>
                    </div>


                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1"><?php echo lang('email'); ?></label>
                        <div class="emailClass"></div>
                    </div>

                    <div class="form-group col-md-4">
                        <label><?php echo lang('age'); ?></label>
                        <div class="ageClass"></div>     
                    </div>

                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1"><?php echo lang('address'); ?></label>
                        <div class="addressClass"></div>
                    </div>

                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1"><?php echo lang('gender'); ?></label>
                        <div class="genderClass"></div>
                    </div>

                    <div class="form-group col-md-4">
                        <label for="exampleInputEmail1"><?php echo lang('phone'); ?></label>
                        <div class="phoneClass"></div>
                    </div>

                 <!--   <div class="form-group col-md-4">
                        <label for="exampleInputEmail1"><?php echo lang('blood_group'); ?></label>
                        <div class="bloodgroupClass"></div>
                    </div> -->

                    <div class="form-group col-md-4">
                        <label><?php echo lang('birth_date'); ?></label>
                        <div class="birthdateClass"></div>     
                    </div>






                    <div class="form-group col-md-4">    
                    </div>
                    <div class="form-group col-md-4">    
                    </div>
                    <div class="form-group col-md-4">    
                        <label for="exampleInputEmail1"><?php echo lang('doctor'); ?></label>
                        <div class="doctorClass"></div>
                    </div>
<!--
					<div class="form-group col-md-4">
                     <label for="examination">  Is this your first examination at this office? &nbsp;&nbsp; </label>
					<div class="examinationClass"></div>                    
					</div>	

				


					<div class="form-group col-md-4	" >
					<label for="howdid">  How did you hear about us? </label> <br>
						Referred by: <div class="ref_byClass"></div>
						Insurance Company: <div class="ins_companyClass"> </div>
						Directory: <div class="ins_hear_about_dirClass"> </div>
						Others: <div class="ins_hear_othersClass"> </div>
					</div>					
					
					
					
					

<hr width="100%" />

<!-- medical history -->
					<div class="form-group col-md-12">
				<b><h2 style="float:left;"><u>Medical History</u></h2></b>
				</div>
				<input type="hidden" class="default" name="img_url" value="./uploads/patient.jpg" />

					<div class="form-group col-md-6">
                        <label for="examination">Reasons for today's examination</label>
                        <div class="reason_examinationClass"></div>
						
						
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_relations">Date of last Physical Examination</label>
						<div class="physical_examinationClass"></div>
                    </div>	

<div class="form-group col-md-12">
<label for="agree">Have you had any of the following? (Please tick Yes or No)</label>
  <div class="row">
    <div class="form-group col-md-4">
		<label for="glaucoma">Glaucoma</label>
		<div class="glaucomaClass"></div> &nbsp;&nbsp;
		<br> 		
		<label for="cataracts">Cataracts</label>
		<div class="cataractsClass"></div> &nbsp;&nbsp;
		<br>
		<label for="eye_surgery">Eye Surgery</label>		
		<div class="eyesurgeryClass"></div> &nbsp;&nbsp;
		<br>
		<label for="lazy_eye">Lazy Eye/Eye /turn</label>		
		<div class="lazyeyeClass"></div> &nbsp;&nbsp;
		<br>		
		<label for="light_flashes">Light Flashes</label>
		<div class="lightflashesClass"></div> &nbsp;&nbsp;
		<br>
		<label for="eye_injury">Eye Injury</label>
		<div class="eyeinjuryClass"></div>
		

    </div>
	<div class="form-group col-md-4">
		<label for="floaters">Sudden increase in Floaters</label>
		<div class="floatersClass"></div> 
		<br>
		<label for="sick_others">Others</label><br>			
		<div class="sickothersClass"></div> 
		<br>
		<label for="thyroid_disease">Thyroid Disease</label>
		<div class="thyroiddiseaseClass"></div> &nbsp;&nbsp;
		<br>
		<label for="sinusitis">Sinusitis</label>
		<div class="sinusitisClass"></div> &nbsp;&nbsp;
		<br>
		<label for="hiv">HIV</label>
		<div class="hivClass"></div> &nbsp;&nbsp;
		<br>		
    </div>	
	
    <div class="form-group col-md-4">
		<label for="blood_pressure2">Blood Pressure</label>
		<div class="bloodpressure2Class"></div> &nbsp;&nbsp;
		<br>	
		<label for="diabetes">Diabetes</label>
		<div class="diabetesClass"></div> &nbsp;&nbsp;
		<br>
		<label for="asthma">Asthma</label>
		<div class="asthmaClass"></div> &nbsp;&nbsp;
		<br>
		<label for="respiratory_problem">Other lungs or respiratory problems</label>
		<div class="respiratoryproblemClass"></div> &nbsp;&nbsp;
		<br>	
		<label for="problem_others">Other (describe)</label>
		<div class="problemothersClass"></div> &nbsp;&nbsp;
		<br>		
    </div>    

  </div>
</div>
					<div class="form-group col-md-6">
                     <label for="medications">  Are you currently taking medications? &nbsp;&nbsp; </label>
						<div class="takingmedicationsClass"></div> &nbsp;&nbsp;						
                    </div>	
					

					<div class="form-group col-md-6" >
					<label for="medications_yes">Please list medications </label> <br>
						<div class="medicationsyesClass"></div> 
					</div>					
					
					<div class="form-group col-md-6">
                     <label for="medications">Are you interested in wearing contact lenses? &nbsp;&nbsp; </label>  
					<div class="wearingcontactlensClass"></div> 
                    </div>	

					<div class="form-group col-md-6" >
					<label for="allergies_list">Please list allergies </label> <br>
						<div class="allergieslistClass"></div> 
					</div>	
					
					
					<div class="form-group col-md-6">
                     <label for="allergies">Other &nbsp;&nbsp; </label>
						<div class="otherallergiesClass"></div> 
    
                    </div>						
					
					<div class="form-group col-md-6">
                       <label for="glasses"> Do you wear glasses? &nbsp;&nbsp; </label>  
						<div class="wearglassesClass"></div> 
                    </div>						
										
					<div class="form-group col-md-6">
                     <label for="worn_contacts">  Have you worn Contacts Lens? &nbsp;&nbsp; </label>  
						<div class="worncontactsClass"></div> 
                    </div>	
					
					<div class="form-group col-md-6" >
					<label for="contact_lens_yes">What type of contact lens </label> <br>
					<div class="contactlensyesClass"></div> <br>
					<label for="contact_lens_hours">And how many hours per day? </label> <br>
						<div class="contactlenshoursClass"></div> 
					</div>	
					

					 <hr width="100%" />
					<!--				 <hr width="100%" />
				
					 <div class="form-group col-md-6">
                        <label for="kin_name"><?php echo lang('kin_name'); ?></label>
						<div class="kin_nameClass"></div>	
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_relations"><?php echo lang('kin_relations'); ?></label>
                        <div class="kin_relationsClass"></div>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="kin_phone"><?php echo lang('kin_phone'); ?></label>
                        <div class="kin_phoneClass"></div>
                    </div>
					
					<div class="form-group col-md-6">
                        <label for="kin_email"><?php echo lang('kin_email'); ?></label>
                        <div class="kin_emailClass"></div>
                    </div> -->

                </form>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
</div>



<script src="common/js/codearistos.min.js"></script>

<!--
<script>


    var video = document.getElementById('video');
    // Get access to the camera!
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        // Not adding `{ audio: true }` since we only want video now
        navigator.mediaDevices.getUserMedia({video: true}).then(function (stream) {
            video.src = window.URL.createObjectURL(stream);
            video.play();
        });
    }

    // Elements for taking the snapshot
    var canvas = document.getElementById('canvas');
    var context = canvas.getContext('2d');
    var video = document.getElementById('video');
    // Trigger photo take
    document.getElementById("snap").addEventListener("click", function () {
        context.drawImage(video, 0, 0, 200, 200);
    });

</script>

-->



<script type="text/javascript">

    $(".table").on("click", ".editbutton", function () {
        //    e.preventDefault(e);
        // Get the record's ID via attribute  
        var iid = $(this).attr('data-id');
        $("#img").attr("src", "uploads/cardiology-patient-icon-vector-6244713.jpg");
        $('#editPatientForm').trigger("reset");
        $.ajax({
            url: 'patient/editPatientByJason?id=' + iid,
            method: 'GET',
            data: '',
            dataType: 'json',
        }).success(function (response) {
            // Populate the form fields with the data returned from server

            $('#editPatientForm').find('[name="id"]').val(response.patient.id).end()
            $('#editPatientForm').find('[name="name"]').val(response.patient.name).end()
            $('#editPatientForm').find('[name="first_name"]').val(response.patient.first_name).end()
            $('#editPatientForm').find('[name="last_name"]').val(response.patient.last_name).end()
            $('#editPatientForm').find('[name="password"]').val(response.patient.password).end()
            $('#editPatientForm').find('[name="email"]').val(response.patient.email).end()
            $('#editPatientForm').find('[name="address"]').val(response.patient.address).end()
            $('#editPatientForm').find('[name="phone"]').val(response.patient.phone).end()
            $('#editPatientForm').find('[name="sex"]').val(response.patient.sex).end()
            $('#editPatientForm').find('[name="birthdate"]').val(response.patient.birthdate).end()
            $('#editPatientForm').find('[name="bloodgroup"]').val(response.patient.bloodgroup).end()
            $('#editPatientForm').find('[name="p_id"]').val(response.patient.patient_id).end()            
			$('#editPatientForm').find('[name="kin_name"]').val(response.patient.e_contact).end()
            $('#editPatientForm').find('[name="kin_relations"]').val(response.patient.e_contact_relation).end()
            $('#editPatientForm').find('[name="kin_phone"]').val(response.patient.e_contact_phone).end()
            $('#editPatientForm').find('[name="kin_email"]').val(response.patient.e_contact_email).end()

            if (typeof response.patient.img_url !== 'undefined' && response.patient.img_url != '') {
                $("#img").attr("src", response.patient.img_url);
            }


            $('.js-example-basic-single.doctor').val(response.patient.doctor).trigger('change');

            $('#myModal2').modal('show');

        });
    });

</script>



<script type="text/javascript">

    $(".table").on("click", ".inffo", function () {
        //    e.preventDefault(e);
        // Get the record's ID via attribute  
        var iid = $(this).attr('data-id');
        
        $("#img1").attr("src", "uploads/cardiology-patient-icon-vector-6244713.jpg");
        $('.patientIdClass').html("").end()
        $('.nameClass').html("").end()
        $('.firstnameClass').html("").end()
        $('.lastnameClass').html("").end()
        $('.emailClass').html("").end()
        $('.addressClass').html("").end()
        $('.phoneClass').html("").end()
        $('.genderClass').html("").end()
        $('.birthdateClass').html("").end()
        $('.bloodgroupClass').html("").end()
        $('.doctorClass').html("").end()
        $('.ageClass').html("").end()       
		$('.kin_nameClass').html("").end()
        $('.kin_relationsClass').html("").end()
        $('.kin_phoneClass').html("").end()
        $('.kin_emailClass').html("").end()

        $('.reason_examinationClass').html("").end()
        $('.physical_examinationClass').html("").end()
        $('.glaucomaClass').html("").end()
        $('.cataractsClass').html("").end()
        $('.eyesurgeryClass').html("").end()
        $('.lazyeyeClass').html("").end()
        $('.lightflashesClass').html("").end()
        $('.eyeinjuryClass').html("").end()
        $('.sickothersClass').html("").end()
        $('.floatersClass').html("").end()       
		$('.thyroiddiseaseClass').html("").end()
        $('.sinusitisClass').html("").end()
        $('.hivClass').html("").end()
        $('.bloodpressure2Class').html("").end()        
		
		$('.diabetesClass').html("").end()
        $('.asthmaClass').html("").end()
        $('.respiratoryproblemClass').html("").end()
        $('.problemothersClass').html("").end()
        $('.takingmedicationsClass').html("").end()
        $('.medicationsyesClass').html("").end()
        $('.wearingcontactlensClass').html("").end()
        $('.allergieslistClass').html("").end()       
		$('.otherallergiesClass').html("").end()
        $('.wearglassesClass').html("").end()
        $('.worncontactsClass').html("").end()
        $('.contactlensyesClass').html("").end()
        $('.contactlenshoursClass').html("").end()		
        $.ajax({
            url: 'patient/getPatientByJason?id=' + iid,
            method: 'GET', 
            data: '',
            dataType: 'json', 
        }).success(function (response) {
            // Populate the form fields with the data returned from server

            $('.patientIdClass').append(response.patient.id).end()
            $('.physical_examinationClass').append(response.patient.physical_examination).end()
            $('.glaucomaClass').append(response.patient.glaucoma).end()
            $('.cataractsClass').append(response.patient.cataracts).end()
            $('.eyesurgeryClass').append(response.patient.eye_surgery).end()
            $('.lazyeyeClass').append(response.patient.lazy_eye).end()
            $('.lightflashesClass').append(response.patient.light_flashes).end()
            $('.floatersClass').append(response.patient.floaters).end()
            $('.eyeinjuryClass').append(response.patient.eye_injury).end()
            $('.sickothersClass').append(response.patient.sick_others).end()            
			$('.thyroiddiseaseClass').append(response.patient.thyroid_disease).end()
            $('.sinusitisClass').append(response.patient.sinusitis).end()
            $('.hivClass').append(response.patient.hiv).end()
            $('.bloodpressure2Class').append(response.patient.blood_pressure2).end()           

			$('.reason_examinationClass').append(response.patient.reason_examination).end()
            $('.nameClass').append(response.patient.name).end()
            $('.firstnameClass').append(response.patient.first_name).end()
            $('.lastnameClass').append(response.patient.last_name).end()
            $('.emailClass').append(response.patient.email).end()
            $('.addressClass').append(response.patient.address).end()
            $('.phoneClass').append(response.patient.phone).end()
            $('.genderClass').append(response.patient.sex).end()
            $('.birthdateClass').append(response.patient.birthdate).end()
            $('.ageClass').append(response.patient.age).end()
            $('.bloodgroupClass').append(response.patient.bloodgroup).end()
            $('.doctorClass').append(response.doctor.name).end()            
			$('.kin_nameClass').append(response.patient.e_contact).end()
            $('.kin_relationsClass').append(response.patient.e_contact_relation).end()
            $('.kin_phoneClass').append(response.patient.e_contact_phone).end()
            $('.kin_emailClass').append(response.patient.e_contact_email).end()           

			$('.diabetesClass').append(response.patient.diabetes).end()
            $('.asthmaClass').append(response.patient.asthma).end()
            $('.respiratoryproblemClass').append(response.patient.respiratory_problem).end()
            $('.problemothersClass').append(response.patient.problem_others).end()
            $('.takingmedicationsClass').append(response.patient.taking_medications).end()
            $('.medicationsyesClass').append(response.patient.medications_yes).end()
            $('.wearingcontactlensClass').append(response.patient.wearing_contact_lens).end()
            $('.allergieslistClass').append(response.patient.allergies_list).end()
            $('.otherallergiesClass').append(response.patient.other_allergies).end()            
			$('.wearglassesClass').append(response.patient.wear_glasses).end()
            $('.worncontactsClass').append(response.patient.worn_contacts).end()
            $('.contactlensyesClass').append(response.patient.contact_lens_yes).end()
            $('.contactlenshoursClass').append(response.patient.contact_lens_hours).end()

            if (typeof response.patient.img_url !== 'undefined' && response.patient.img_url != '') {
                $("#img1").attr("src", response.patient.img_url);
            }


            $('#infoModal').modal('show');

        });
    });

</script>





<script>


    $(document).ready(function () {
        var table = $('#editable-sample').DataTable({
            responsive: true,
            //   dom: 'lfrBtip',

            "processing": true,
            "serverSide": true,
            "searchable": true,
            "ajax": {
                url: "patient/getPatient",
                type: 'POST',
            },
            scroller: {
                loadingIndicator: true
            },
            dom: "<'row'<'col-sm-3'l><'col-sm-5 text-center'B><'col-sm-4'f>>" +
                    "<'row'<'col-sm-12'tr>>" +
                    "<'row'<'col-sm-5'i><'col-sm-7'p>>",
            buttons: [
                'copyHtml5',
                'excelHtml5',
                'csvHtml5',
                'pdfHtml5',
                {
                    extend: 'print',
                    exportOptions: {
                        columns: [0, 1, 2],
                    }
                },
            ],
            aLengthMenu: [
                [10, 25, 50, 100, -1],
                [10, 25, 50, 100, "All"]
            ],
            iDisplayLength: 25,
            "order": [[0, "asc"]],

            "language": {
                "lengthMenu": "_MENU_",
                search: "_INPUT_",
                "url": "common/assets/DataTables/languages/<?php echo $this->language; ?>.json"
            }
        });
        table.buttons().container().appendTo('.custom_buttons');
    });

</script>



<script>
    $(document).ready(function () {
        $(".flashmessage").delay(3000).fadeOut(100);
    });
</script>


